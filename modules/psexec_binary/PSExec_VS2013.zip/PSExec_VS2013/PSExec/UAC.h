#pragma once
#include "stdafx.h"
#include <atlbase.h>
#include <atlsecurity.h>

class UAC {
	public:
		BOOL IsElevated();
		bool isInAdminGroup(HRESULT &rHr);
		void startAsAdmin();
};

