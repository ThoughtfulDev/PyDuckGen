/*
	Used for elevating admin rights
*/
#include "stdafx.h"
#include "UAC.h"
std::string psexecdir();



BOOL UAC::IsElevated() {
	BOOL fRet = FALSE;
	HANDLE hToken = NULL;
	if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken)) {
		TOKEN_ELEVATION Elevation;
		DWORD cbSize = sizeof(TOKEN_ELEVATION);
		if (GetTokenInformation(hToken, TokenElevation, &Elevation, sizeof(Elevation), &cbSize)) {
			fRet = Elevation.TokenIsElevated;
		}
	}
	if (hToken) {
		CloseHandle(hToken);
	}
	return fRet;
}

void UAC::startAsAdmin() {
	ShellExecute(NULL,
		"runas",
		psexecdir().c_str(),
		"report.txt",
		NULL,
		SW_HIDE
	);
}

bool UAC::isInAdminGroup(HRESULT &rHr) {
	bool bIsAdmin = false;
	try
	{
		// Open the access token of the current process.
		ATL::CAccessToken aToken;
		if (!aToken.GetProcessToken(TOKEN_QUERY))
		{
			throw MAKE_SCODE(SEVERITY_ERROR, FACILITY_WIN32,
				::GetLastError());
		}


		// Query for the access token's group information.
		ATL::CTokenGroups groups;
		if (!aToken.GetGroups(&groups))
		{
			throw MAKE_SCODE(SEVERITY_ERROR, FACILITY_WIN32,
				::GetLastError());
		}

		// Iterate through the access token's groups
		// looking for a match against the builtin admins group.
		ATL::CSid::CSidArray groupSids;
		ATL::CAtlArray<DWORD> groupAttribs;
		groups.GetSidsAndAttributes(&groupSids, &groupAttribs);
		for (UINT i = 0; !bIsAdmin && i < groupSids.GetCount(); ++i)
		{
			bIsAdmin = groupSids.GetAt(i) == ATL::Sids::Admins();
		}
		rHr = S_OK;
	}
	catch (HRESULT hr)
	{
		rHr = hr;
	}

	return bIsAdmin;
}

std::string psexecdir() {
	char result[MAX_PATH];
	std::string full = std::string(result, GetModuleFileName(NULL, result, MAX_PATH));
	std::string ret = full.substr(0, full.length() - 11);
	return ret + "\\PSExec.exe";
	
}